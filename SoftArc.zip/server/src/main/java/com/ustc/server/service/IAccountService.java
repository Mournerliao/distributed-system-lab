package com.ustc.server.service;

import com.baomidou.mybatisplus.service.IService;
import com.ustc.server.entity.account;

public interface IAccountService extends IService<account> {
}
